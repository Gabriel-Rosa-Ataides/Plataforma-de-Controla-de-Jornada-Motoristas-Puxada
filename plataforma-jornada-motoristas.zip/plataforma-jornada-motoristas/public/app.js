// Configuração da API
const API_BASE_URL = 'http://localhost:3001/api';

// Estado global da aplicação
let currentUser = null;
let currentRole = null;

// Inicialização da aplicação
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 Aplicação inicializada!');
    initializeApp();
    setupEventListeners();
    
    // Adicionar event listeners para os cards clicáveis
    setupCardListeners();
    
    // Adicionar event listeners para as abas
    setupTabListeners();
});

// Configurar event listeners dos cards
function setupCardListeners() {
    console.log('🔧 Configurando listeners dos cards...');
    
    // Adicionar listeners para os cards clicáveis
    const cards = document.querySelectorAll('.clickable-card');
    cards.forEach((card, index) => {
        console.log(`📱 Configurando card ${index + 1}`);
        card.addEventListener('click', function() {
            console.log(`🎯 Card ${index + 1} clicado!`);
            showLoginModal();
        });
    });
    
    console.log(`✅ ${cards.length} cards configurados`);
}

// Configurar event listeners das abas
function setupTabListeners() {
    console.log('🔧 Configurando listeners das abas...');
    
    // Event listeners para abas do motorista
    const motoristaTabs = document.querySelectorAll('#motoristaSection .list-group-item');
    motoristaTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            const tabName = this.getAttribute('data-tab');
            console.log('Aba motorista clicada:', tabName);
            showMotoristaTab(tabName);
        });
    });
    
    // Event listeners para abas do admin
    const adminTabs = document.querySelectorAll('#adminSection .list-group-item');
    adminTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            const tabName = this.getAttribute('data-tab');
            console.log('Aba admin clicada:', tabName);
            showAdminTab(tabName);
        });
    });
    
    console.log(`✅ ${motoristaTabs.length + adminTabs.length} abas configuradas`);
}

// Configuração inicial
function initializeApp() {
    // Verificar se há usuário logado
    const token = localStorage.getItem('token');
    if (token) {
        verifyToken(token);
    }
}

// Configurar event listeners
function setupEventListeners() {
    // Formulário de login
    document.getElementById('loginForm').addEventListener('submit', handleLogin);
}

// Funções de autenticação
async function handleLogin(event) {
    event.preventDefault();
    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    
    try {
        const response = await fetch(`${API_BASE_URL}/auth/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password })
        });
        
        const data = await response.json();
        
        if (data.success) {
            localStorage.setItem('token', data.token);
            currentUser = data.user;
            currentRole = data.user.role;
            
            // Fechar modal e mostrar interface apropriada
            const loginModal = bootstrap.Modal.getInstance(document.getElementById('loginModal'));
            loginModal.hide();
            
            showUserInterface();
        } else {
            showAlert('Erro no login: ' + data.error, 'danger');
        }
    } catch (error) {
        console.error('Erro no login:', error);
        showAlert('Erro de conexão. Tente novamente.', 'danger');
    }
}

async function verifyToken(token) {
    try {
        const response = await fetch(`${API_BASE_URL}/auth/verify`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        const data = await response.json();
        
        if (data.valid) {
            currentUser = data.user;
            currentRole = data.user.role;
            showUserInterface();
        } else {
            localStorage.removeItem('token');
        }
    } catch (error) {
        console.error('Erro na verificação do token:', error);
        localStorage.removeItem('token');
    }
}

function logout() {
    localStorage.removeItem('token');
    currentUser = null;
    currentRole = null;
    showWelcomeSection();
}

// Interface do usuário
function showUserInterface() {
    document.getElementById('welcomeSection').classList.add('d-none');
    document.getElementById('loginSection').classList.add('d-none');
    document.getElementById('userSection').classList.remove('d-none');
    
    // Mostrar informações do usuário
    document.getElementById('userInfo').textContent = `${currentUser.nome} (${currentUser.role})`;
    
    // Mostrar seção apropriada baseada no role
    if (currentRole === 'motorista') {
        document.getElementById('motoristaSection').classList.remove('d-none');
        showMotoristaTab('nova-jornada');
    } else if (currentRole === 'admin') {
        document.getElementById('adminSection').classList.remove('d-none');
        showAdminTab('dashboard');
    }
}

function showWelcomeSection() {
    document.getElementById('welcomeSection').classList.remove('d-none');
    document.getElementById('motoristaSection').classList.add('d-none');
    document.getElementById('adminSection').classList.add('d-none');
    document.getElementById('loginSection').classList.remove('d-none');
    document.getElementById('userSection').classList.add('d-none');
}

// Funções do motorista
function showMotoristaTab(tab) {
    console.log('Mostrando aba do motorista:', tab);
    
    // Atualizar menu ativo
    document.querySelectorAll('#motoristaSection .list-group-item').forEach(item => {
        item.classList.remove('active');
    });
    
    // Encontrar o botão correto e ativá-lo
    const activeButton = document.querySelector(`#motoristaSection .list-group-item[onclick*="${tab}"]`);
    if (activeButton) {
        activeButton.classList.add('active');
    }
    
    const content = document.getElementById('motoristaContent');
    
    switch (tab) {
        case 'nova-jornada':
            content.innerHTML = createNovaJornadaForm();
            break;
        case 'minhas-jornadas':
            content.innerHTML = createMinhasJornadasView();
            loadMinhasJornadas();
            break;
        case 'perfil':
            content.innerHTML = createPerfilView();
            loadPerfil();
            break;
        case 'estatisticas':
            content.innerHTML = createEstatisticasView();
            loadEstatisticas();
            break;
    }
}

function createNovaJornadaForm() {
    return `
        <div class="card fade-in">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0"><i class="fas fa-plus me-2"></i>Nova Jornada de Trabalho</h5>
                <small class="text-light">Preencha todos os campos obrigatórios para registrar sua jornada</small>
            </div>
            <div class="card-body">
                <form id="jornadaForm">
                    <!-- Dados do Motorista -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <h6 class="text-primary border-bottom pb-2 mb-3">
                                <i class="fas fa-user me-2"></i>Dados do Motorista
                            </h6>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label fw-bold">Nome do Motorista</label>
                                <input type="text" class="form-control form-control-lg" id="motoristaNome" value="${currentUser.nome}" readonly>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label fw-bold">Placa do Veículo</label>
                                <input type="text" class="form-control form-control-lg" id="placa" value="${currentUser.placa || ''}" required 
                                       placeholder="ABC-1234" maxlength="8">
                                <div class="form-text">Formato: ABC-1234</div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Dados da Viagem -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <h6 class="text-primary border-bottom pb-2 mb-3">
                                <i class="fas fa-route me-2"></i>Dados da Viagem
                            </h6>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label fw-bold">KM Inicial</label>
                                <input type="number" class="form-control form-control-lg" id="kmInicial" required 
                                       placeholder="0" min="0">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label fw-bold">KM Final</label>
                                <input type="number" class="form-control form-control-lg" id="kmFinal" required 
                                       placeholder="0" min="0">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label fw-bold">Destino</label>
                                <input type="text" class="form-control form-control-lg" id="destino" required 
                                       placeholder="Nome da fábrica ou local">
                            </div>
                        </div>
                    </div>
                    
                    <!-- Horários -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <h6 class="text-primary border-bottom pb-2 mb-3">
                                <i class="fas fa-clock me-2"></i>Horários da Jornada
                            </h6>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label fw-bold">Saída da Empresa</label>
                                <input type="datetime-local" class="form-control form-control-lg" id="saidaEmpresa" required>
                                <div class="form-text">Data e hora de saída</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label fw-bold">Chegada na Fábrica</label>
                                <input type="datetime-local" class="form-control form-control-lg" id="chegadaFabrica" required>
                                <div class="form-text">Data e hora de chegada</div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Refeição/Descanso -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <h6 class="text-primary border-bottom pb-2 mb-3">
                                <i class="fas fa-utensils me-2"></i>Refeição e Descanso
                            </h6>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label fw-bold">Início da Refeição</label>
                                <input type="datetime-local" class="form-control form-control-lg" id="inicioRefeicao">
                                <div class="form-text">Opcional - para cálculo de tempo de descanso</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label fw-bold">Fim da Refeição</label>
                                <input type="datetime-local" class="form-control form-control-lg" id="fimRefeicao">
                                <div class="form-text">Opcional - para cálculo de tempo de descanso</div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Tempo de Espera -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <h6 class="text-primary border-bottom pb-2 mb-3">
                                <i class="fas fa-hourglass-half me-2"></i>Tempo de Espera na Fábrica
                            </h6>
                        </div>
                        <div class="col-12">
                            <div class="mb-3">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="teveEspera" style="transform: scale(1.5);">
                                    <label class="form-check-label fw-bold ms-2">Teve tempo de espera na fábrica?</label>
                                </div>
                            </div>
                            <div id="esperaFields" class="d-none">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label fw-bold">Início da Espera</label>
                                            <input type="datetime-local" class="form-control form-control-lg" id="inicioEspera">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label fw-bold">Fim da Espera</label>
                                            <input type="datetime-local" class="form-control form-control-lg" id="fimEspera">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Informações Adicionais -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <h6 class="text-primary border-bottom pb-2 mb-3">
                                <i class="fas fa-info-circle me-2"></i>Informações Adicionais
                            </h6>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label fw-bold">Data da Jornada</label>
                                <input type="date" class="form-control form-control-lg" id="dataJornada" 
                                       value="${moment().format('YYYY-MM-DD')}" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label fw-bold">Observações</label>
                                <textarea class="form-control form-control-lg" id="observacoes" rows="3" 
                                          placeholder="Anotações importantes sobre a jornada, problemas encontrados, etc..."></textarea>
                                <div class="form-text">Descreva qualquer situação relevante durante a jornada</div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Botões de Ação -->
                    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                        <button type="button" class="btn btn-secondary btn-lg me-md-2" onclick="resetForm()">
                            <i class="fas fa-undo me-2"></i>Limpar Formulário
                        </button>
                        <button type="submit" class="btn btn-primary btn-lg">
                            <i class="fas fa-save me-2"></i>Salvar Jornada
                        </button>
                    </div>
                </form>
            </div>
        </div>
    `;
}

// Funções do administrador
function showAdminTab(tab) {
    console.log('Mostrando aba do admin:', tab);
    
    // Atualizar menu ativo
    document.querySelectorAll('#adminSection .list-group-item').forEach(item => {
        item.classList.remove('active');
    });
    
    // Encontrar o botão correto e ativá-lo
    const activeButton = document.querySelector(`#adminSection .list-group-item[onclick*="${tab}"]`);
    if (activeButton) {
        activeButton.classList.add('active');
    }
    
    const content = document.getElementById('adminContent');
    
    switch (tab) {
        case 'dashboard':
            content.innerHTML = createDashboardView();
            loadDashboard();
            break;
        case 'jornadas':
            content.innerHTML = createJornadasView();
            loadJornadas();
            break;
        case 'motoristas':
            content.innerHTML = createMotoristasView();
            loadMotoristas();
            break;
        case 'relatorios':
            content.innerHTML = createRelatoriosView();
            break;
        case 'usuarios':
            content.innerHTML = createUsuariosView();
            loadUsuarios();
            break;
    }
}

function createDashboardView() {
    return `
        <div class="row fade-in">
            <div class="col-12 mb-4">
                <h4><i class="fas fa-tachometer-alt me-2"></i>Dashboard</h4>
            </div>
            
            <div class="col-md-3 mb-4">
                <div class="stats-card">
                    <div class="stats-number" id="totalJornadas">0</div>
                    <div class="stats-label">Total de Jornadas</div>
                </div>
            </div>
            
            <div class="col-md-3 mb-4">
                <div class="stats-card">
                    <div class="stats-number" id="jornadasAssinadas">0</div>
                    <div class="stats-label">Jornadas Assinadas</div>
                </div>
            </div>
            
            <div class="col-md-3 mb-4">
                <div class="stats-card">
                    <div class="stats-number" id="totalKm">0</div>
                    <div class="stats-label">Total de KM</div>
                </div>
            </div>
            
            <div class="col-md-3 mb-4">
                <div class="stats-card">
                    <div class="stats-number" id="totalHoras">0</div>
                    <div class="stats-label">Total de Horas</div>
                </div>
            </div>
            
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-chart-line me-2"></i>Estatísticas por Motorista</h5>
                    </div>
                    <div class="card-body">
                        <div id="estatisticasMotoristas">
                            <div class="text-center">
                                <div class="spinner mx-auto"></div>
                                <p class="mt-2">Carregando estatísticas...</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
}

// Funções utilitárias
function showLoginModal() {
    console.log('Tentando abrir modal de login...');
    
    try {
        // Verificar se o Bootstrap está disponível
        if (typeof bootstrap !== 'undefined' && bootstrap.Modal) {
            console.log('Bootstrap disponível, usando modal...');
            const loginModal = document.getElementById('loginModal');
            if (loginModal) {
                const modal = new bootstrap.Modal(loginModal);
                modal.show();
                console.log('Modal aberto com sucesso!');
                return;
            }
        } else {
            console.log('Bootstrap não disponível, usando fallback...');
        }
        
        // Fallback: mostrar formulário inline
        showInlineLogin();
        
    } catch (error) {
        console.error('Erro ao abrir modal:', error);
        console.log('Usando fallback devido ao erro...');
        showInlineLogin();
    }
}

function showInlineLogin() {
    console.log('Mostrando login inline...');
    
    // Salvar o conteúdo original para poder restaurar
    const welcomeSection = document.getElementById('welcomeSection');
    const originalContent = welcomeSection.innerHTML;
    
    const loginForm = `
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card shadow-lg">
                    <div class="card-header bg-primary text-white text-center">
                        <h4 class="mb-0">
                            <i class="fas fa-sign-in-alt me-2"></i>Login da Plataforma
                        </h4>
                        <small class="text-light">Faça login para acessar o sistema</small>
                    </div>
                    <div class="card-body p-4">
                        <form id="inlineLoginForm">
                            <div class="mb-3">
                                <label for="inlineUsername" class="form-label fw-bold">
                                    <i class="fas fa-user me-2"></i>Usuário
                                </label>
                                <input type="text" class="form-control form-control-lg" 
                                       id="inlineUsername" required 
                                       placeholder="Digite seu usuário">
                            </div>
                            <div class="mb-3">
                                <label for="inlinePassword" class="form-label fw-bold">
                                    <i class="fas fa-lock me-2"></i>Senha
                                </label>
                                <input type="password" class="form-control form-control-lg" 
                                       id="inlinePassword" required 
                                       placeholder="Digite sua senha">
                            </div>
                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary btn-lg">
                                    <i class="fas fa-sign-in-alt me-2"></i>Entrar no Sistema
                                </button>
                                <button type="button" class="btn btn-outline-secondary" onclick="restoreWelcomeSection()">
                                    <i class="fas fa-arrow-left me-2"></i>Voltar
                                </button>
                            </div>
                        </form>
                        
                        <div class="mt-4 text-center">
                            <small class="text-muted">
                                <strong>Usuários de teste:</strong><br>
                                <strong>Admin:</strong> admin / admin123<br>
                                <strong>Motorista:</strong> motorista1 / motorista123
                            </small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    welcomeSection.innerHTML = loginForm;
    
    // Adicionar event listener para o formulário inline
    document.getElementById('inlineLoginForm').addEventListener('submit', handleInlineLogin);
    
    // Adicionar função para restaurar a tela inicial
    window.restoreWelcomeSection = function() {
        welcomeSection.innerHTML = originalContent;
        // Reconfigurar os event listeners dos cards
        setupCardListeners();
    };
}

async function handleInlineLogin(event) {
    event.preventDefault();
    
    const username = document.getElementById('inlineUsername').value;
    const password = document.getElementById('inlinePassword').value;
    
    try {
        const response = await fetch(`${API_BASE_URL}/auth/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password })
        });
        
        const data = await response.json();
        
        if (data.success) {
            localStorage.setItem('token', data.token);
            currentUser = data.user;
            currentRole = data.user.role;
            
            showUserInterface();
        } else {
            showAlert('Erro no login: ' + data.error, 'danger');
        }
    } catch (error) {
        console.error('Erro no login:', error);
        showAlert('Erro de conexão. Tente novamente.', 'danger');
    }
}

function showAlert(message, type = 'info') {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    // Inserir no topo da página
    const container = document.querySelector('.container');
    container.insertBefore(alertDiv, container.firstChild);
    
    // Auto-remover após 5 segundos
    setTimeout(() => {
        if (alertDiv.parentNode) {
            alertDiv.remove();
        }
    }, 5000);
}

// Event listeners para campos condicionais
document.addEventListener('change', function(e) {
    if (e.target.id === 'teveEspera') {
        const esperaFields = document.getElementById('esperaFields');
        if (esperaFields) {
            if (e.target.checked) {
                esperaFields.classList.remove('d-none');
            } else {
                esperaFields.classList.add('d-none');
            }
        }
    }
});

// Função para resetar formulário
function resetForm() {
    document.getElementById('jornadaForm').reset();
    document.getElementById('esperaFields').classList.add('d-none');
    document.getElementById('dataJornada').value = moment().format('YYYY-MM-DD');
}

// Função para carregar dashboard
async function loadDashboard() {
    try {
        const response = await fetch(`${API_BASE_URL}/admin/estatisticas`);
        const data = await response.json();
        
        if (data.success) {
            const stats = data.estatisticas.geral;
            document.getElementById('totalJornadas').textContent = stats.totalJornadas;
            document.getElementById('jornadasAssinadas').textContent = stats.jornadasAssinadas;
            document.getElementById('totalKm').textContent = stats.totalKm;
            document.getElementById('totalHoras').textContent = stats.totalHoras.toFixed(1);
            
            // Carregar estatísticas por motorista
            loadEstatisticasMotoristas(data.estatisticas.porMotorista);
        }
    } catch (error) {
        console.error('Erro ao carregar dashboard:', error);
        showAlert('Erro ao carregar dashboard', 'danger');
    }
}

function loadEstatisticasMotoristas(motoristas) {
    const container = document.getElementById('estatisticasMotoristas');
    
    if (motoristas.length === 0) {
        container.innerHTML = '<p class="text-muted text-center">Nenhum motorista encontrado</p>';
        return;
    }
    
    let html = '<div class="table-responsive"><table class="table table-hover">';
    html += '<thead><tr><th>Motorista</th><th>Jornadas</th><th>Total KM</th><th>Total Horas</th><th>Média KM</th></tr></thead><tbody>';
    
    motoristas.forEach(motorista => {
        html += `
            <tr>
                <td>${motorista.nome}</td>
                <td>${motorista.totalJornadas}</td>
                <td>${motorista.totalKm}</td>
                <td>${motorista.totalHoras.toFixed(1)}h</td>
                <td>${motorista.totalJornadas > 0 ? (motorista.totalKm / motorista.totalJornadas).toFixed(1) : 0}</td>
            </tr>
        `;
    });
    
    html += '</tbody></table></div>';
    container.innerHTML = html;
}

// Função para carregar jornadas
async function loadJornadas() {
    try {
        const response = await fetch(`${API_BASE_URL}/admin/jornadas`);
        const data = await response.json();
        
        if (data.success) {
            displayJornadas(data.jornadas);
        }
    } catch (error) {
        console.error('Erro ao carregar jornadas:', error);
        showAlert('Erro ao carregar jornadas', 'danger');
    }
}

function displayJornadas(jornadas) {
    const container = document.getElementById('jornadasContainer');
    
    if (jornadas.length === 0) {
        container.innerHTML = '<p class="text-muted text-center">Nenhuma jornada encontrada</p>';
        return;
    }
    
    let html = '<div class="table-responsive"><table class="table table-hover">';
    html += '<thead><tr><th>Data</th><th>Motorista</th><th>Placa</th><th>Destino</th><th>KM</th><th>Tempo</th><th>Status</th><th>Ações</th></tr></thead><tbody>';
    
    jornadas.forEach(jornada => {
        const statusClass = jornada.status === 'assinada' ? 'status-assinada' : 'status-pendente';
        html += `
            <tr>
                <td>${moment(jornada.dataJornada).format('DD/MM/YYYY')}</td>
                <td>${jornada.motoristaNome}</td>
                <td>${jornada.placa}</td>
                <td>${jornada.destino}</td>
                <td>${jornada.kmTotal}</td>
                <td>${jornada.tempoJornada.horas}h${jornada.tempoJornada.minutos}m</td>
                <td><span class="badge ${statusClass}">${jornada.status}</span></td>
                <td>
                    <div class="action-buttons">
                        <button class="btn btn-sm btn-info" onclick="viewJornada('${jornada.id}')">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="btn btn-sm btn-success" onclick="downloadPDF('${jornada.id}')">
                            <i class="fas fa-download"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `;
    });
    
    html += '</tbody></table></div>';
    container.innerHTML = html;
}

// Função para download de PDF
async function downloadPDF(jornadaId) {
    try {
        window.open(`${API_BASE_URL}/admin/jornada/${jornadaId}/pdf`, '_blank');
    } catch (error) {
        console.error('Erro ao baixar PDF:', error);
        showAlert('Erro ao baixar PDF', 'danger');
    }
}

// Função para visualizar jornada
function viewJornada(jornadaId) {
    // Implementar modal de visualização
    showAlert('Funcionalidade de visualização em desenvolvimento', 'info');
}

// Função para carregar motoristas
async function loadMotoristas() {
    try {
        const response = await fetch(`${API_BASE_URL}/motorista`);
        const data = await response.json();
        
        if (data.success) {
            displayMotoristas(data.motoristas);
        }
    } catch (error) {
        console.error('Erro ao carregar motoristas:', error);
        showAlert('Erro ao carregar motoristas', 'danger');
    }
}

function displayMotoristas(motoristas) {
    const container = document.getElementById('motoristasContainer');
    
    if (motoristas.length === 0) {
        container.innerHTML = '<p class="text-muted text-center">Nenhum motorista encontrado</p>';
        return;
    }
    
    let html = '<div class="table-responsive"><table class="table table-hover">';
    html += '<thead><tr><th>Nome</th><th>CPF</th><th>CNH</th><th>Placa</th><th>Status</th><th>Ações</th></tr></thead><tbody>';
    
    motoristas.forEach(motorista => {
        const statusClass = motorista.status === 'ativo' ? 'status-assinada' : 'status-cancelada';
        html += `
            <tr>
                <td>${motorista.nome}</td>
                <td>${motorista.cpf}</td>
                <td>${motorista.cnh} (${motorista.categoriaCnh})</td>
                <td>${motorista.placa}</td>
                <td><span class="badge ${statusClass}">${motorista.status}</span></td>
                <td>
                    <div class="action-buttons">
                        <button class="btn btn-sm btn-info" onclick="viewMotorista('${motorista.id}')">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="btn btn-sm btn-warning" onclick="editMotorista('${motorista.id}')">
                            <i class="fas fa-edit"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `;
    });
    
    html += '</tbody></table></div>';
    container.innerHTML = html;
}

// Função para carregar usuários
async function loadUsuarios() {
    try {
        const response = await fetch(`${API_BASE_URL}/auth/users`);
        const data = await response.json();
        
        if (data.success) {
            displayUsuarios(data.users);
        }
    } catch (error) {
        console.error('Erro ao carregar usuários:', error);
        showAlert('Erro ao carregar usuários', 'danger');
    }
}

function displayUsuarios(usuarios) {
    const container = document.getElementById('usuariosContainer');
    
    if (usuarios.length === 0) {
        container.innerHTML = '<p class="text-muted text-center">Nenhum usuário encontrado</p>';
        return;
    }
    
    let html = '<div class="table-responsive"><table class="table table-hover">';
    html += '<thead><tr><th>Nome</th><th>Usuário</th><th>Email</th><th>Função</th><th>Ações</th></tr></thead><tbody>';
    
    usuarios.forEach(usuario => {
        const roleClass = usuario.role === 'admin' ? 'status-assinada' : 'status-pendente';
        html += `
            <tr>
                <td>${usuario.nome}</td>
                <td>${usuario.username}</td>
                <td>${usuario.email}</td>
                <td><span class="badge ${roleClass}">${usuario.role}</span></td>
                <td>
                    <div class="action-buttons">
                        <button class="btn btn-sm btn-warning" onclick="editUsuario('${usuario.id}')">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn btn-sm btn-danger" onclick="deleteUsuario('${usuario.id}')">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `;
    });
    
    html += '</tbody></table></div>';
    container.innerHTML = html;
}

// Funções de carregamento de dados
async function loadMinhasJornadas() {
    try {
        const response = await fetch(`${API_BASE_URL}/jornada/motorista/${currentUser.id}`, {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            displayMinhasJornadas(data.jornadas);
        } else {
            document.getElementById('jornadasList').innerHTML = `
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    ${data.error || 'Erro ao carregar jornadas'}
                </div>
            `;
        }
    } catch (error) {
        console.error('Erro ao carregar jornadas:', error);
        document.getElementById('jornadasList').innerHTML = `
            <div class="alert alert-danger">
                <i class="fas fa-times-circle me-2"></i>
                Erro de conexão. Tente novamente.
            </div>
        `;
    }
}

async function loadPerfil() {
    // Perfil já está carregado com os dados do usuário
    console.log('Perfil carregado para:', currentUser.nome);
}

async function loadEstatisticas() {
    try {
        const response = await fetch(`${API_BASE_URL}/jornada/estatisticas/${currentUser.id}`, {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            const stats = data.estatisticas;
            document.getElementById('totalMinhasJornadas').textContent = stats.totalJornadas || 0;
            document.getElementById('totalMeusKm').textContent = stats.totalKm || 0;
            document.getElementById('totalMinhasHoras').textContent = (stats.totalHoras || 0).toFixed(1);
            document.getElementById('mediaKmJornada').textContent = (stats.mediaKm || 0).toFixed(1);
            
            // Estatísticas do mês
            document.getElementById('jornadasMes').textContent = stats.jornadasMes || 0;
            document.getElementById('kmMes').textContent = stats.kmMes || 0;
            document.getElementById('horasMes').textContent = (stats.horasMes || 0).toFixed(1);
        }
    } catch (error) {
        console.error('Erro ao carregar estatísticas:', error);
    }
}

async function loadJornadas() {
    try {
        const response = await fetch(`${API_BASE_URL}/jornada/todas`, {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            displayTodasJornadas(data.jornadas);
        } else {
            document.getElementById('todasJornadasList').innerHTML = `
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    ${data.error || 'Erro ao carregar jornadas'}
                </div>
            `;
        }
    } catch (error) {
        console.error('Erro ao carregar jornadas:', error);
        document.getElementById('todasJornadasList').innerHTML = `
            <div class="alert alert-danger">
                <i class="fas fa-times-circle me-2"></i>
                Erro de conexão. Tente novamente.
            </div>
        `;
    }
}

async function loadMotoristas() {
    try {
        const response = await fetch(`${API_BASE_URL}/motorista/todos`, {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            displayMotoristas(data.motoristas);
        } else {
            document.getElementById('motoristasList').innerHTML = `
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    ${data.error || 'Erro ao carregar motoristas'}
                </div>
            `;
        }
    } catch (error) {
        console.error('Erro ao carregar motoristas:', error);
        document.getElementById('motoristasList').innerHTML = `
            <div class="alert alert-danger">
                <i class="fas fa-times-circle me-2"></i>
                Erro de conexão. Tente novamente.
            </div>
        `;
    }
}

async function loadUsuarios() {
    try {
        const response = await fetch(`${API_BASE_URL}/auth/usuarios`, {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            displayUsuarios(data.usuarios);
        } else {
            document.getElementById('usuariosList').innerHTML = `
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    ${data.error || 'Erro ao carregar usuários'}
                </div>
            `;
        }
    } catch (error) {
        console.error('Erro ao carregar usuários:', error);
        document.getElementById('usuariosList').innerHTML = `
            <div class="alert alert-danger">
                <i class="fas fa-times-circle me-2"></i>
                Erro de conexão. Tente novamente.
            </div>
        `;
    }
}

// Função para carregar minhas jornadas
function displayMinhasJornadas(jornadas) {
    const container = document.getElementById('jornadasList');
    
    if (jornadas.length === 0) {
        container.innerHTML = '<p class="text-muted text-center">Nenhuma jornada encontrada</p>';
        return;
    }
    
    let html = '<div class="table-responsive"><table class="table table-hover">';
    html += '<thead><tr><th>Data</th><th>Placa</th><th>Destino</th><th>KM</th><th>Tempo</th><th>Status</th><th>Ações</th></tr></thead><tbody>';
    
    jornadas.forEach(jornada => {
        const statusClass = jornada.status === 'assinada' ? 'status-assinada' : 'status-pendente';
        html += `
            <tr>
                <td>${moment(jornada.dataJornada).format('DD/MM/YYYY')}</td>
                <td>${jornada.placa}</td>
                <td>${jornada.destino}</td>
                <td>${jornada.kmTotal}</td>
                <td>${jornada.tempoJornada.horas}h${jornada.tempoJornada.minutos}m</td>
                <td><span class="badge ${statusClass}">${jornada.status}</span></td>
                <td>
                    <div class="action-buttons">
                        <button class="btn btn-sm btn-info" onclick="viewMinhaJornada('${jornada.id}')">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="btn btn-sm btn-warning" onclick="editMinhaJornada('${jornada.id}')">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn btn-sm btn-danger" onclick="deleteMinhaJornada('${jornada.id}')">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `;
    });
    
    html += '</tbody></table></div>';
    container.innerHTML = html;
}

// Função para carregar perfil
function displayPerfil(motorista) {
    const container = document.getElementById('perfilContainer');
    
    container.innerHTML = `
        <div class="card fade-in">
            <div class="card-header">
                <h5 class="mb-0"><i class="fas fa-user me-2"></i>Meu Perfil</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <h6 class="text-primary mb-3">Informações Pessoais</h6>
                        <div class="mb-3">
                            <label class="form-label">Nome Completo</label>
                            <input type="text" class="form-control" value="${motorista.nome}" readonly>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">CPF</label>
                            <input type="text" class="form-control" value="${motorista.cpf}" readonly>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" class="form-control" value="${motorista.email}" readonly>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <h6 class="text-primary mb-3">Informações Profissionais</h6>
                        <div class="mb-3">
                            <label class="form-label">CNH</label>
                            <input type="text" class="form-control" value="${motorista.cnh} (${motorista.categoriaCnh})" readonly>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Placa do Veículo</label>
                            <input type="text" class="form-control" value="${motorista.placa}" readonly>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Data de Admissão</label>
                            <input type="text" class="form-control" value="${moment(motorista.dataAdmissao).format('DD/MM/YYYY')}" readonly>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
}

// Função para carregar estatísticas
function displayEstatisticas(estatisticas) {
    const container = document.getElementById('estatisticasContainer');
    
    container.innerHTML = `
        <div class="row fade-in">
            <div class="col-md-3 mb-4">
                <div class="stats-card">
                    <div class="stats-number">${estatisticas.totalJornadas}</div>
                    <div class="stats-label">Total de Jornadas</div>
                </div>
            </div>
            
            <div class="col-md-3 mb-4">
                <div class="stats-card">
                    <div class="stats-number">${estatisticas.totalKm}</div>
                    <div class="stats-label">Total de KM</div>
                </div>
            </div>
            
            <div class="col-md-3 mb-4">
                <div class="stats-card">
                    <div class="stats-number">${estatisticas.totalHoras.toFixed(1)}</div>
                    <div class="stats-label">Total de Horas</div>
                </div>
            </div>
            
            <div class="col-md-3 mb-4">
                <div class="stats-card">
                    <div class="stats-number">${estatisticas.mediaKmPorJornada.toFixed(1)}</div>
                    <div class="stats-label">Média KM/Jornada</div>
                </div>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="fas fa-chart-bar me-2"></i>Histórico de Jornadas</h5>
            </div>
            <div class="card-body">
                <div class="timeline">
                    ${estatisticas.jornadas.map(jornada => `
                        <div class="timeline-item">
                            <div class="card">
                                <div class="card-body">
                                    <h6 class="card-title">${moment(jornada.dataJornada).format('DD/MM/YYYY')} - ${jornada.destino}</h6>
                                    <p class="card-text">
                                        <strong>Placa:</strong> ${jornada.placa} | 
                                        <strong>KM:</strong> ${jornada.kmTotal} | 
                                        <strong>Tempo:</strong> ${jornada.tempoJornada.horas}h${jornada.tempoJornada.minutos}m
                                    </p>
                                    <span class="badge ${jornada.status === 'assinada' ? 'status-assinada' : 'status-pendente'}">${jornada.status}</span>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        </div>
    `;
}

// Função para salvar jornada
async function saveJornada(formData) {
    try {
        const response = await fetch(`${API_BASE_URL}/jornada`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            },
            body: JSON.stringify(formData)
        });
        
        const data = await response.json();
        
        if (data.success) {
            showAlert('Jornada salva com sucesso!', 'success');
            resetForm();
        } else {
            showAlert('Erro ao salvar jornada: ' + data.error, 'danger');
        }
    } catch (error) {
        console.error('Erro ao salvar jornada:', error);
        showAlert('Erro de conexão. Tente novamente.', 'danger');
    }
}

// Event listener para formulário de jornada
document.addEventListener('submit', function(e) {
    if (e.target.id === 'jornadaForm') {
        e.preventDefault();
        
        const formData = {
            motoristaId: currentUser.id,
            motoristaNome: document.getElementById('motoristaNome').value,
            placa: document.getElementById('placa').value,
            kmInicial: document.getElementById('kmInicial').value,
            kmFinal: document.getElementById('kmFinal').value,
            destino: document.getElementById('destino').value,
            saidaEmpresa: document.getElementById('saidaEmpresa').value,
            inicioRefeicao: document.getElementById('inicioRefeicao').value || null,
            fimRefeicao: document.getElementById('fimRefeicao').value || null,
            chegadaFabrica: document.getElementById('chegadaFabrica').value,
            teveEspera: document.getElementById('teveEspera').checked,
            inicioEspera: document.getElementById('inicioEspera').value || null,
            fimEspera: document.getElementById('fimEspera').value || null,
            observacoes: document.getElementById('observacoes').value,
            dataJornada: document.getElementById('dataJornada').value
        };
        
        saveJornada(formData);
    }
});

// Funções de criação das views do motorista
function createMinhasJornadasView() {
    return `
        <div class="card fade-in">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0"><i class="fas fa-list me-2"></i>Minhas Jornadas</h5>
                <small class="text-light">Histórico completo das suas jornadas de trabalho</small>
            </div>
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-search"></i></span>
                            <input type="text" class="form-control" id="searchJornadas" placeholder="Buscar jornadas...">
                        </div>
                    </div>
                    <div class="col-md-6 text-end">
                        <button class="btn btn-success" onclick="exportarMinhasJornadas()">
                            <i class="fas fa-download me-2"></i>Exportar
                        </button>
                    </div>
                </div>
                
                <div id="jornadasList">
                    <div class="text-center">
                        <div class="spinner mx-auto"></div>
                        <p class="mt-2">Carregando suas jornadas...</p>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function createPerfilView() {
    return `
        <div class="card fade-in">
            <div class="card-header bg-info text-white">
                <h5 class="mb-0"><i class="fas fa-user-cog me-2"></i>Meu Perfil</h5>
                <small class="text-light">Gerencie suas informações pessoais</small>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <h6 class="text-primary mb-3">Informações Pessoais</h6>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Nome Completo</label>
                            <input type="text" class="form-control" id="perfilNome" value="${currentUser.nome}" readonly>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Usuário</label>
                            <input type="text" class="form-control" id="perfilUsuario" value="${currentUser.username}" readonly>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Email</label>
                            <input type="email" class="form-control" id="perfilEmail" value="${currentUser.email}">
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Placa do Veículo</label>
                            <input type="text" class="form-control" id="perfilPlaca" value="${currentUser.placa || ''}">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <h6 class="text-primary mb-3">Alterar Senha</h6>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Senha Atual</label>
                            <input type="password" class="form-control" id="senhaAtual" placeholder="Digite sua senha atual">
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Nova Senha</label>
                            <input type="password" class="form-control" id="novaSenha" placeholder="Digite a nova senha">
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Confirmar Nova Senha</label>
                            <input type="password" class="form-control" id="confirmarSenha" placeholder="Confirme a nova senha">
                        </div>
                        <button class="btn btn-warning" onclick="alterarSenha()">
                            <i class="fas fa-key me-2"></i>Alterar Senha
                        </button>
                    </div>
                </div>
                
                <div class="row mt-4">
                    <div class="col-12">
                        <button class="btn btn-primary" onclick="salvarPerfil()">
                            <i class="fas fa-save me-2"></i>Salvar Alterações
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function createEstatisticasView() {
    return `
        <div class="card fade-in">
            <div class="card-header bg-success text-white">
                <h5 class="mb-0"><i class="fas fa-chart-bar me-2"></i>Minhas Estatísticas</h5>
                <small class="text-light">Resumo do seu desempenho e atividades</small>
            </div>
            <div class="card-body">
                <div class="row mb-4">
                    <div class="col-md-3">
                        <div class="stats-card bg-primary text-white">
                            <div class="stats-number" id="totalMinhasJornadas">0</div>
                            <div class="stats-label">Total de Jornadas</div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stats-card bg-success text-white">
                            <div class="stats-number" id="totalMeusKm">0</div>
                            <div class="stats-label">Total de KM</div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stats-card bg-info text-white">
                            <div class="stats-number" id="totalMinhasHoras">0</div>
                            <div class="stats-label">Total de Horas</div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stats-card bg-warning text-white">
                            <div class="stats-number" id="mediaKmJornada">0</div>
                            <div class="stats-label">Média KM/Jornada</div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-8">
                        <div class="card">
                            <div class="card-header">
                                <h6 class="mb-0"><i class="fas fa-chart-line me-2"></i>Jornadas por Mês</h6>
                            </div>
                            <div class="card-body">
                                <div id="graficoJornadasMes">
                                    <div class="text-center">
                                        <div class="spinner mx-auto"></div>
                                        <p class="mt-2">Carregando gráfico...</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header">
                                <h6 class="mb-0"><i class="fas fa-info-circle me-2"></i>Resumo</h6>
                            </div>
                            <div class="card-body">
                                <div class="list-group list-group-flush">
                                    <div class="list-group-item d-flex justify-content-between">
                                        <span>Jornadas este mês</span>
                                        <span class="badge bg-primary" id="jornadasMes">0</span>
                                    </div>
                                    <div class="list-group-item d-flex justify-content-between">
                                        <span>KM este mês</span>
                                        <span class="badge bg-success" id="kmMes">0</span>
                                    </div>
                                    <div class="list-group-item d-flex justify-content-between">
                                        <span>Horas este mês</span>
                                        <span class="badge bg-info" id="horasMes">0</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
}

// Funções de criação das views do admin
function createJornadasView() {
    return `
        <div class="card fade-in">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0"><i class="fas fa-list me-2"></i>Todas as Jornadas</h5>
                <small class="text-light">Gestão completa de todas as jornadas dos motoristas</small>
            </div>
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-md-4">
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-search"></i></span>
                            <input type="text" class="form-control" id="searchJornadasAdmin" placeholder="Buscar jornadas...">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <select class="form-select" id="filterStatus">
                            <option value="">Todos os Status</option>
                            <option value="pendente">Pendente</option>
                            <option value="assinada">Assinada</option>
                            <option value="finalizada">Finalizada</option>
                        </select>
                    </div>
                    <div class="col-md-4 text-end">
                        <button class="btn btn-success" onclick="exportarTodasJornadas()">
                            <i class="fas fa-download me-2"></i>Exportar
                        </button>
                    </div>
                </div>
                
                <div id="todasJornadasList">
                    <div class="text-center">
                        <div class="spinner mx-auto"></div>
                        <p class="mt-2">Carregando jornadas...</p>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function createMotoristasView() {
    return `
        <div class="card fade-in">
            <div class="card-header bg-success text-white">
                <h5 class="mb-0"><i class="fas fa-users me-2"></i>Gestão de Motoristas</h5>
                <small class="text-light">Administre os motoristas da empresa</small>
            </div>
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-search"></i></span>
                            <input type="text" class="form-control" id="searchMotoristas" placeholder="Buscar motoristas...">
                        </div>
                    </div>
                    <div class="col-md-6 text-end">
                        <button class="btn btn-primary" onclick="showAddMotoristaModal()">
                            <i class="fas fa-plus me-2"></i>Novo Motorista
                        </button>
                    </div>
                </div>
                
                <div id="motoristasList">
                    <div class="text-center">
                        <div class="spinner mx-auto"></div>
                        <p class="mt-2">Carregando motoristas...</p>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function createRelatoriosView() {
    return `
        <div class="card fade-in">
            <div class="card-header bg-warning text-white">
                <h5 class="mb-0"><i class="fas fa-file-pdf me-2"></i>Relatórios</h5>
                <small class="text-light">Gere relatórios detalhados da operação</small>
            </div>
            <div class="card-body">
                <div class="row mb-4">
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h6 class="mb-0"><i class="fas fa-calendar me-2"></i>Relatório por Período</h6>
                            </div>
                            <div class="card-body">
                                <div class="mb-3">
                                    <label class="form-label">Data Inicial</label>
                                    <input type="date" class="form-control" id="dataInicial">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Data Final</label>
                                    <input type="date" class="form-control" id="dataFinal">
                                </div>
                                <button class="btn btn-primary" onclick="gerarRelatorioPeriodo()">
                                    <i class="fas fa-file-pdf me-2"></i>Gerar Relatório
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h6 class="mb-0"><i class="fas fa-user me-2"></i>Relatório por Motorista</h6>
                            </div>
                            <div class="card-body">
                                <div class="mb-3">
                                    <label class="form-label">Selecionar Motorista</label>
                                    <select class="form-select" id="motoristaRelatorio">
                                        <option value="">Todos os motoristas</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Mês/Ano</label>
                                    <input type="month" class="form-control" id="mesAno">
                                </div>
                                <button class="btn btn-success" onclick="gerarRelatorioMotorista()">
                                    <i class="fas fa-file-pdf me-2"></i>Gerar Relatório
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h6 class="mb-0"><i class="fas fa-download me-2"></i>Relatórios Rápidos</h6>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-3">
                                        <button class="btn btn-outline-primary w-100 mb-2" onclick="gerarRelatorioDiario()">
                                            <i class="fas fa-calendar-day me-2"></i>Relatório Diário
                                        </button>
                                    </div>
                                    <div class="col-md-3">
                                        <button class="btn btn-outline-success w-100 mb-2" onclick="gerarRelatorioSemanal()">
                                            <i class="fas fa-calendar-week me-2"></i>Relatório Semanal
                                        </button>
                                    </div>
                                    <div class="col-md-3">
                                        <button class="btn btn-outline-info w-100 mb-2" onclick="gerarRelatorioMensal()">
                                            <i class="fas fa-calendar-alt me-2"></i>Relatório Mensal
                                        </button>
                                    </div>
                                    <div class="col-md-3">
                                        <button class="btn btn-outline-warning w-100 mb-2" onclick="gerarRelatorioAnual()">
                                            <i class="fas fa-calendar me-2"></i>Relatório Anual
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function createUsuariosView() {
    return `
        <div class="card fade-in">
            <div class="card-header bg-danger text-white">
                <h5 class="mb-0"><i class="fas fa-user-plus me-2"></i>Gestão de Usuários</h5>
                <small class="text-light">Administre todos os usuários do sistema</small>
            </div>
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-search"></i></span>
                            <input type="text" class="form-control" id="searchUsuarios" placeholder="Buscar usuários...">
                        </div>
                    </div>
                    <div class="col-md-6 text-end">
                        <button class="btn btn-primary" onclick="showAddUsuarioModal()">
                            <i class="fas fa-plus me-2"></i>Novo Usuário
                        </button>
                    </div>
                </div>
                
                <div id="usuariosList">
                    <div class="text-center">
                        <div class="spinner mx-auto"></div>
                        <p class="mt-2">Carregando usuários...</p>
                    </div>
                </div>
            </div>
        </div>
    `;
}
