# 📋 Instruções de Instalação - Plataforma de Jornada

## ⚠️ Problema de Segurança do PowerShell

Se você encontrar o erro:
```
O arquivo C:\Program Files\nodejs\npm.ps1 não pode ser carregado porque a execução de scripts foi desabilitada neste sistema
```

## 🔧 Soluções

### Opção 1: Usar Prompt de Comando (CMD)
1. Pressione `Win + R`
2. Digite `cmd` e pressione Enter
3. Navegue até a pasta do projeto:
   ```cmd
   cd "C:\Users\Gabriel Rosa Ataides\plataforma-jornada-motoristas"
   ```
4. Execute os comandos:
   ```cmd
   npm install
   npm start
   ```

### Opção 2: Alterar Política de Execução do PowerShell
1. Abra PowerShell como Administrador
2. Execute o comando:
   ```powershell
   Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
   ```
3. Digite `S` para confirmar
4. Agora você pode usar npm normalmente

### Opção 3: Usar Terminal do VS Code
1. Abra a pasta do projeto no VS Code
2. Pressione `Ctrl + `` (backtick) para abrir o terminal
3. Execute os comandos normalmente

## 🚀 Passos de Instalação

### 1. Verificar Node.js
```bash
node --version
npm --version
```
Se não estiver instalado, baixe em: https://nodejs.org/


### 2. Instalar Dependências
```bash
npm install
```

### 3. Configurar Variáveis de Ambiente
Copie o arquivo `config.env.example` para `.env` e configure:
```bash
copy config.env.example .env
```

### 4. Iniciar o Servidor
```bash
# Modo desenvolvimento
npm run dev

# Modo produção
npm start
```

### 5. Acessar a Aplicação
Abra o navegador e acesse: `http://localhost:3001`

## 🔐 Usuários de Teste

### Administrador
- **Usuário**: `admin`
- **Senha**: `admin123`

### Motorista
- **Usuário**: `motorista1`
- **Senha**: `motorista123`

## 📁 Estrutura Final do Projeto

Após a instalação, sua estrutura deve ficar assim:
```
plataforma-jornada-motoristas/
├── node_modules/           # Dependências instaladas
├── public/                 # Frontend
├── routes/                 # Rotas da API
├── models/                 # Modelos
├── middleware/             # Middlewares
├── utils/                  # Utilitários
├── server.js              # Servidor
├── package.json           # Dependências
├── package-lock.json      # Lock das versões
├── .env                   # Configurações (criar)
├── config.env.example     # Exemplo de configuração
├── README.md              # Documentação
└── INSTALACAO.md          # Este arquivo
```

## 🐛 Solução de Problemas Comuns

### Erro: "Cannot find module"
```bash
rm -rf node_modules package-lock.json
npm install
```

### Erro: "Port already in use"
```bash
# Windows
netstat -ano | findstr :3001
taskkill /PID <PID> /F

# Ou mude a porta no arquivo .env
PORT=3002
```

### Erro: "Permission denied"
Execute o terminal como administrador

### Erro: "npm not found"
Reinstale o Node.js ou verifique o PATH

## 📞 Suporte

Se ainda tiver problemas:
1. Verifique se o Node.js está instalado corretamente
2. Tente usar o CMD em vez do PowerShell
3. Verifique as permissões da pasta
4. Consulte a documentação oficial do Node.js

## ✅ Verificação de Instalação

Após a instalação bem-sucedida:
- ✅ `npm install` executou sem erros
- ✅ `npm start` inicia o servidor
- ✅ Acesse `http://localhost:3001` no navegador
- ✅ A página de login aparece
- ✅ Consegue fazer login com os usuários de teste

---

**Revenda Lima** - Sistema de Controle de Jornada © 2024
