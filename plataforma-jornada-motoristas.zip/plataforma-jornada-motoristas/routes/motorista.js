const express = require('express');
const moment = require('moment');
const router = express.Router();

// Simulação de banco de dados em memória para motoristas
let motoristas = [
  {
    id: '1',
    nome: 'João Silva',
    cpf: '123.456.789-00',
    cnh: '12345678901',
    categoriaCnh: 'E',
    telefone: '(64) 99999-9999',
    email: 'joao.silva@revendalima.com',
    placa: 'ABC-1234',
    dataAdmissao: '2020-01-15',
    status: 'ativo'
  },
  {
    id: '2',
    nome: 'Pedro Santos',
    cpf: '987.654.321-00',
    cnh: '98765432109',
    categoriaCnh: 'E',
    telefone: '(64) 88888-8888',
    email: 'pedro.santos@revendalima.com',
    placa: 'XYZ-5678',
    dataAdmissao: '2019-03-20',
    status: 'ativo'
  }
];

// Middleware para verificar se o usuário é motorista
const authenticateMotorista = (req, res, next) => {
  // Em produção, verificar JWT token e role motorista aqui
  next();
};

// Rota para obter perfil do motorista
router.get('/perfil/:id', authenticateMotorista, (req, res) => {
  try {
    const { id } = req.params;
    const motorista = motoristas.find(m => m.id === id);

    if (!motorista) {
      return res.status(404).json({
        error: 'Motorista não encontrado'
      });
    }

    res.json({
      success: true,
      motorista
    });

  } catch (error) {
    console.error('Erro ao obter perfil do motorista:', error);
    res.status(500).json({
      error: 'Erro interno do servidor'
    });
  }
});

// Rota para atualizar perfil do motorista
router.put('/perfil/:id', authenticateMotorista, (req, res) => {
  try {
    const { id } = req.params;
    const motoristaIndex = motoristas.findIndex(m => m.id === id);

    if (motoristaIndex === -1) {
      return res.status(404).json({
        error: 'Motorista não encontrado'
      });
    }

    const motoristaAtualizado = {
      ...motoristas[motoristaIndex],
      ...req.body,
      dataAtualizacao: moment().toISOString()
    };

    motoristas[motoristaIndex] = motoristaAtualizado;

    res.json({
      success: true,
      message: 'Perfil atualizado com sucesso',
      motorista: motoristaAtualizado
    });

  } catch (error) {
    console.error('Erro ao atualizar perfil:', error);
    res.status(500).json({
      error: 'Erro interno do servidor'
    });
  }
});

// Rota para obter histórico de jornadas do motorista
router.get('/:id/historico', authenticateMotorista, (req, res) => {
  try {
    const { id } = req.params;
    const { dataInicio, dataFim, status } = req.query;

    // Em produção, buscar jornadas do banco de dados
    // Por enquanto, retornar array vazio
    let jornadas = [];

    // Filtro por data
    if (dataInicio && dataFim) {
      jornadas = jornadas.filter(j => {
        const dataJornada = moment(j.dataJornada);
        return dataJornada.isBetween(dataInicio, dataFim, 'day', '[]');
      });
    }

    // Filtro por status
    if (status) {
      jornadas = jornadas.filter(j => j.status === status);
    }

    // Ordenar por data de criação (mais recente primeiro)
    jornadas.sort((a, b) => moment(b.dataCriacao).diff(moment(a.dataCriacao)));

    // Calcular estatísticas do motorista
    const totalJornadas = jornadas.length;
    const jornadasAssinadas = jornadas.filter(j => j.status === 'assinada').length;
    const totalKm = jornadas.reduce((sum, j) => sum + j.kmTotal, 0);
    const totalHoras = jornadas.reduce((sum, j) => sum + j.tempoJornada.total, 0);

    res.json({
      success: true,
      motoristaId: id,
      jornadas,
      total: jornadas.length,
      estatisticas: {
        totalJornadas,
        jornadasAssinadas,
        jornadasPendentes: totalJornadas - jornadasAssinadas,
        totalKm,
        totalHoras,
        mediaKmPorJornada: totalJornadas > 0 ? Math.round((totalKm / totalJornadas) * 100) / 100 : 0,
        mediaHorasPorJornada: totalJornadas > 0 ? Math.round((totalHoras / totalJornadas) * 100) / 100 : 0
      },
      filtros: {
        dataInicio,
        dataFim,
        status
      }
    });

  } catch (error) {
    console.error('Erro ao obter histórico:', error);
    res.status(500).json({
      error: 'Erro interno do servidor'
    });
  }
});

// Rota para obter resumo mensal do motorista
router.get('/:id/resumo-mensal/:ano/:mes', authenticateMotorista, (req, res) => {
  try {
    const { id, ano, mes } = req.params;
    
    // Em produção, buscar jornadas do banco de dados
    // Por enquanto, retornar dados simulados
    const resumoMensal = {
      ano: parseInt(ano),
      mes: parseInt(mes),
      totalJornadas: 0,
      totalKm: 0,
      totalHoras: 0,
      jornadasAssinadas: 0,
      jornadasPendentes: 0,
      mediaKmPorJornada: 0,
      mediaHorasPorJornada: 0,
      diasTrabalhados: 0,
      diasDescanso: 0
    };

    res.json({
      success: true,
      motoristaId: id,
      resumoMensal
    });

  } catch (error) {
    console.error('Erro ao obter resumo mensal:', error);
    res.status(500).json({
      error: 'Erro interno do servidor'
    });
  }
});

// Rota para obter próximas viagens programadas
router.get('/:id/proximas-viagens', authenticateMotorista, (req, res) => {
  try {
    const { id } = req.params;
    
    // Em produção, buscar viagens programadas do banco de dados
    // Por enquanto, retornar array vazio
    const proximasViagens = [];

    res.json({
      success: true,
      motoristaId: id,
      proximasViagens,
      total: proximasViagens.length
    });

  } catch (error) {
    console.error('Erro ao obter próximas viagens:', error);
    res.status(500).json({
      error: 'Erro interno do servidor'
    });
  }
});

// Rota para obter documentos do motorista
router.get('/:id/documentos', authenticateMotorista, (req, res) => {
  try {
    const { id } = req.params;
    
    // Em produção, buscar documentos do banco de dados
    const documentos = [
      {
        id: '1',
        tipo: 'CNH',
        numero: '12345678901',
        categoria: 'E',
        validade: '2025-12-31',
        status: 'valido'
      },
      {
        id: '2',
        tipo: 'Exame Médico',
        validade: '2024-12-31',
        status: 'valido'
      }
    ];

    res.json({
      success: true,
      motoristaId: id,
      documentos,
      total: documentos.length
    });

  } catch (error) {
    console.error('Erro ao obter documentos:', error);
    res.status(500).json({
      error: 'Erro interno do servidor'
    });
  }
});

// Rota para obter notificações do motorista
router.get('/:id/notificacoes', authenticateMotorista, (req, res) => {
  try {
    const { id } = req.params;
    
    // Em produção, buscar notificações do banco de dados
    const notificacoes = [
      {
        id: '1',
        titulo: 'Jornada Pendente',
        mensagem: 'Você tem uma jornada pendente de assinatura',
        tipo: 'aviso',
        data: moment().subtract(1, 'hour').toISOString(),
        lida: false
      }
    ];

    res.json({
      success: true,
      motoristaId: id,
      notificacoes,
      total: notificacoes.length,
      naoLidas: notificacoes.filter(n => !n.lida).length
    });

  } catch (error) {
    console.error('Erro ao obter notificações:', error);
    res.status(500).json({
      error: 'Erro interno do servidor'
    });
  }
});

// Rota para marcar notificação como lida
router.put('/:id/notificacoes/:notificacaoId/lida', authenticateMotorista, (req, res) => {
  try {
    const { id, notificacaoId } = req.params;
    
    // Em produção, atualizar notificação no banco de dados
    res.json({
      success: true,
      message: 'Notificação marcada como lida'
    });

  } catch (error) {
    console.error('Erro ao marcar notificação como lida:', error);
    res.status(500).json({
      error: 'Erro interno do servidor'
    });
  }
});

module.exports = router;
