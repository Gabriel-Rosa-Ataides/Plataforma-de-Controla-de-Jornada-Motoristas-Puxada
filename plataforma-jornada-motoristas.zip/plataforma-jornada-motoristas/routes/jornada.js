const express = require('express');
const { v4: uuidv4 } = require('uuid');
const moment = require('moment');
const router = express.Router();

// Simulação de banco de dados em memória para jornadas
let jornadas = [];

// Middleware para verificar se o usuário está autenticado
const authenticateUser = (req, res, next) => {
  // Em produção, verificar JWT token aqui
  next();
};

// Rota para criar nova jornada
router.post('/', authenticateUser, (req, res) => {
  try {
    const {
      motoristaId,
      motoristaNome,
      placa,
      kmInicial,
      kmFinal,
      destino,
      saidaEmpresa,
      inicioRefeicao,
      fimRefeicao,
      chegadaFabrica,
      teveEspera,
      inicioEspera,
      fimEspera,
      observacoes,
      dataJornada
    } = req.body;

    // Validações básicas
    if (!motoristaId || !motoristaNome || !placa || !kmInicial || !kmFinal || !destino) {
      return res.status(400).json({
        error: 'Campos obrigatórios não preenchidos'
      });
    }

    // Calcular tempo total da jornada
    const saida = moment(saidaEmpresa);
    const chegada = moment(chegadaFabrica);
    const tempoJornada = moment.duration(chegada.diff(saida));

    // Calcular tempo de espera se houver
    let tempoEspera = null;
    if (teveEspera && inicioEspera && fimEspera) {
      const inicio = moment(inicioEspera);
      const fim = moment(fimEspera);
      tempoEspera = moment.duration(fim.diff(inicio));
    }

    // Calcular tempo de refeição
    let tempoRefeicao = null;
    if (inicioRefeicao && fimRefeicao) {
      const inicio = moment(inicioRefeicao);
      const fim = moment(fimRefeicao);
      tempoRefeicao = moment.duration(fim.diff(inicio));
    }

    const novaJornada = {
      id: uuidv4(),
      motoristaId,
      motoristaNome,
      placa,
      kmInicial: parseInt(kmInicial),
      kmFinal: parseInt(kmFinal),
      kmTotal: parseInt(kmFinal) - parseInt(kmInicial),
      destino,
      saidaEmpresa,
      inicioRefeicao,
      fimRefeicao,
      chegadaFabrica,
      teveEspera,
      inicioEspera,
      fimEspera,
      tempoJornada: {
        horas: tempoJornada.hours(),
        minutos: tempoJornada.minutes(),
        total: tempoJornada.asHours()
      },
      tempoEspera: tempoEspera ? {
        horas: tempoEspera.hours(),
        minutos: tempoEspera.minutes(),
        total: tempoEspera.asHours()
      } : null,
      tempoRefeicao: tempoRefeicao ? {
        horas: tempoRefeicao.hours(),
        minutos: tempoRefeicao.minutes(),
        total: tempoRefeicao.asHours()
      } : null,
      observacoes,
      dataJornada: dataJornada || moment().format('YYYY-MM-DD'),
      dataCriacao: moment().toISOString(),
      assinaturaMotorista: null,
      assinaturaGerente: null,
      status: 'pendente'
    };

    jornadas.push(novaJornada);

    res.status(201).json({
      success: true,
      message: 'Jornada criada com sucesso',
      jornada: novaJornada
    });

  } catch (error) {
    console.error('Erro ao criar jornada:', error);
    res.status(500).json({
      error: 'Erro interno do servidor'
    });
  }
});

// Rota para listar jornadas do motorista
router.get('/motorista/:motoristaId', authenticateUser, (req, res) => {
  try {
    const { motoristaId } = req.params;
    const { dataInicio, dataFim, status } = req.query;

    let jornadasFiltradas = jornadas.filter(j => j.motoristaId === motoristaId);

    // Filtro por data
    if (dataInicio && dataFim) {
      jornadasFiltradas = jornadasFiltradas.filter(j => {
        const dataJornada = moment(j.dataJornada);
        return dataJornada.isBetween(dataInicio, dataFim, 'day', '[]');
      });
    }

    // Filtro por status
    if (status) {
      jornadasFiltradas = jornadasFiltradas.filter(j => j.status === status);
    }

    // Ordenar por data de criação (mais recente primeiro)
    jornadasFiltradas.sort((a, b) => moment(b.dataCriacao).diff(moment(a.dataCriacao)));

    res.json({
      success: true,
      jornadas: jornadasFiltradas,
      total: jornadasFiltradas.length
    });

  } catch (error) {
    console.error('Erro ao listar jornadas:', error);
    res.status(500).json({
      error: 'Erro interno do servidor'
    });
  }
});

// Rota para obter jornada específica
router.get('/:id', authenticateUser, (req, res) => {
  try {
    const { id } = req.params;
    const jornada = jornadas.find(j => j.id === id);

    if (!jornada) {
      return res.status(404).json({
        error: 'Jornada não encontrada'
      });
    }

    res.json({
      success: true,
      jornada
    });

  } catch (error) {
    console.error('Erro ao obter jornada:', error);
    res.status(500).json({
      error: 'Erro interno do servidor'
    });
  }
});

// Rota para atualizar jornada
router.put('/:id', authenticateUser, (req, res) => {
  try {
    const { id } = req.params;
    const jornadaIndex = jornadas.findIndex(j => j.id === id);

    if (jornadaIndex === -1) {
      return res.status(404).json({
        error: 'Jornada não encontrada'
      });
    }

    const jornadaAtualizada = {
      ...jornadas[jornadaIndex],
      ...req.body,
      dataAtualizacao: moment().toISOString()
    };

    jornadas[jornadaIndex] = jornadaAtualizada;

    res.json({
      success: true,
      message: 'Jornada atualizada com sucesso',
      jornada: jornadaAtualizada
    });

  } catch (error) {
    console.error('Erro ao atualizar jornada:', error);
    res.status(500).json({
      error: 'Erro interno do servidor'
    });
  }
});

// Rota para adicionar assinatura do motorista
router.post('/:id/assinatura-motorista', authenticateUser, (req, res) => {
  try {
    const { id } = req.params;
    const { assinatura } = req.body;

    if (!assinatura) {
      return res.status(400).json({
        error: 'Assinatura é obrigatória'
      });
    }

    const jornadaIndex = jornadas.findIndex(j => j.id === id);
    if (jornadaIndex === -1) {
      return res.status(404).json({
        error: 'Jornada não encontrada'
      });
    }

    jornadas[jornadaIndex].assinaturaMotorista = assinatura;
    jornadas[jornadaIndex].dataAtualizacao = moment().toISOString();

    res.json({
      success: true,
      message: 'Assinatura do motorista adicionada com sucesso'
    });

  } catch (error) {
    console.error('Erro ao adicionar assinatura:', error);
    res.status(500).json({
      error: 'Erro interno do servidor'
    });
  }
});

// Rota para adicionar assinatura do gerente
router.post('/:id/assinatura-gerente', authenticateUser, (req, res) => {
  try {
    const { id } = req.params;
    const { assinatura } = req.body;

    if (!assinatura) {
      return res.status(400).json({
        error: 'Assinatura é obrigatória'
      });
    }

    const jornadaIndex = jornadas.findIndex(j => j.id === id);
    if (jornadaIndex === -1) {
      return res.status(404).json({
        error: 'Jornada não encontrada'
      });
    }

    jornadas[jornadaIndex].assinaturaGerente = assinatura;
    jornadas[jornadaIndex].status = 'assinada';
    jornadas[jornadaIndex].dataAtualizacao = moment().toISOString();

    res.json({
      success: true,
      message: 'Assinatura do gerente adicionada com sucesso'
    });

  } catch (error) {
    console.error('Erro ao adicionar assinatura:', error);
    res.status(500).json({
      error: 'Erro interno do servidor'
    });
  }
});

// Rota para deletar jornada (apenas se não estiver assinada)
router.delete('/:id', authenticateUser, (req, res) => {
  try {
    const { id } = req.params;
    const jornadaIndex = jornadas.findIndex(j => j.id === id);

    if (jornadaIndex === -1) {
      return res.status(404).json({
        error: 'Jornada não encontrada'
      });
    }

    if (jornadas[jornadaIndex].status === 'assinada') {
      return res.status(400).json({
        error: 'Não é possível deletar uma jornada já assinada'
      });
    }

    jornadas.splice(jornadaIndex, 1);

    res.json({
      success: true,
      message: 'Jornada deletada com sucesso'
    });

  } catch (error) {
    console.error('Erro ao deletar jornada:', error);
    res.status(500).json({
      error: 'Erro interno do servidor'
    });
  }
});

module.exports = router;
