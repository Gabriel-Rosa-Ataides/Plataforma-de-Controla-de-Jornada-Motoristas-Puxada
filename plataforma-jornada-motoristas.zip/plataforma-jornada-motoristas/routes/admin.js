const express = require('express');
const PDFDocument = require('pdfkit');
const moment = require('moment');
const router = express.Router();

// Simulação de banco de dados em memória para jornadas (importar do arquivo jornada.js)
let jornadas = [];

// Middleware para verificar se o usuário é administrador
const authenticateAdmin = (req, res, next) => {
  // Em produção, verificar JWT token e role admin aqui
  next();
};

// Rota para listar todas as jornadas (apenas admin)
router.get('/jornadas', authenticateAdmin, (req, res) => {
  try {
    const { dataInicio, dataFim, motoristaId, status, placa } = req.query;

    let jornadasFiltradas = [...jornadas];

    // Filtro por data
    if (dataInicio && dataFim) {
      jornadasFiltradas = jornadasFiltradas.filter(j => {
        const dataJornada = moment(j.dataJornada);
        return dataJornada.isBetween(dataInicio, dataFim, 'day', '[]');
      });
    }

    // Filtro por motorista
    if (motoristaId) {
      jornadasFiltradas = jornadasFiltradas.filter(j => j.motoristaId === motoristaId);
    }

    // Filtro por status
    if (status) {
      jornadasFiltradas = jornadasFiltradas.filter(j => j.status === status);
    }

    // Filtro por placa
    if (placa) {
      jornadasFiltradas = jornadasFiltradas.filter(j => 
        j.placa.toLowerCase().includes(placa.toLowerCase())
      );
    }

    // Ordenar por data de criação (mais recente primeiro)
    jornadasFiltradas.sort((a, b) => moment(b.dataCriacao).diff(moment(a.dataCriacao)));

    res.json({
      success: true,
      jornadas: jornadasFiltradas,
      total: jornadasFiltradas.length,
      filtros: {
        dataInicio,
        dataFim,
        motoristaId,
        status,
        placa
      }
    });

  } catch (error) {
    console.error('Erro ao listar jornadas:', error);
    res.status(500).json({
      error: 'Erro interno do servidor'
    });
  }
});

// Rota para gerar PDF de uma jornada específica
router.get('/jornada/:id/pdf', authenticateAdmin, (req, res) => {
  try {
    const { id } = req.params;
    const jornada = jornadas.find(j => j.id === id);

    if (!jornada) {
      return res.status(404).json({
        error: 'Jornada não encontrada'
      });
    }

    // Configurar cabeçalho para download do PDF
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="jornada-${jornada.id}.pdf"`);

    // Criar documento PDF
    const doc = new PDFDocument({
      size: 'A4',
      margins: {
        top: 50,
        bottom: 50,
        left: 50,
        right: 50
      }
    });

    // Pipe do PDF para a resposta
    doc.pipe(res);

    // Cabeçalho do documento
    doc.fontSize(20)
       .font('Helvetica-Bold')
       .text('CONTROLE DE JORNADA DE TRABALHO', { align: 'center' })
       .moveDown();

    doc.fontSize(12)
       .font('Helvetica')
       .text(`Revenda Lima - ${moment().format('DD/MM/YYYY')}`, { align: 'center' })
       .moveDown(2);

    // Informações do motorista
    doc.fontSize(14)
       .font('Helvetica-Bold')
       .text('DADOS DO MOTORISTA')
       .moveDown();

    doc.fontSize(10)
       .font('Helvetica')
       .text(`Nome: ${jornada.motoristaNome}`)
       .text(`Placa: ${jornada.placa}`)
       .text(`Data da Jornada: ${moment(jornada.dataJornada).format('DD/MM/YYYY')}`)
       .moveDown();

    // Informações da viagem
    doc.fontSize(14)
       .font('Helvetica-Bold')
       .text('DADOS DA VIAGEM')
       .moveDown();

    doc.fontSize(10)
       .font('Helvetica')
       .text(`Destino: ${jornada.destino}`)
       .text(`KM Inicial: ${jornada.kmInicial}`)
       .text(`KM Final: ${jornada.kmFinal}`)
       .text(`KM Total: ${jornada.kmTotal}`)
       .moveDown();

    // Horários
    doc.fontSize(14)
       .font('Helvetica-Bold')
       .text('HORÁRIOS')
       .moveDown();

    doc.fontSize(10)
       .font('Helvetica')
       .text(`Saída da Empresa: ${moment(jornada.saidaEmpresa).format('HH:mm')}`)
       .text(`Chegada na Fábrica: ${moment(jornada.chegadaFabrica).format('HH:mm')}`);

    if (jornada.inicioRefeicao && jornada.fimRefeicao) {
      doc.text(`Início da Refeição: ${moment(jornada.inicioRefeicao).format('HH:mm')}`)
         .text(`Fim da Refeição: ${moment(jornada.fimRefeicao).format('HH:mm')}`)
         .text(`Tempo de Refeição: ${jornada.tempoRefeicao.horas}h ${jornada.tempoRefeicao.minutos}min`);
    }

    if (jornada.teveEspera && jornada.inicioEspera && jornada.fimEspera) {
      doc.text(`Início da Espera: ${moment(jornada.inicioEspera).format('HH:mm')}`)
         .text(`Fim da Espera: ${moment(jornada.fimEspera).format('HH:mm')}`)
         .text(`Tempo de Espera: ${jornada.tempoEspera.horas}h ${jornada.tempoEspera.minutos}min`);
    }

    doc.moveDown()
       .text(`Tempo Total da Jornada: ${jornada.tempoJornada.horas}h ${jornada.tempoJornada.minutos}min`)
       .moveDown();

    // Observações
    if (jornada.observacoes) {
      doc.fontSize(14)
         .font('Helvetica-Bold')
         .text('OBSERVAÇÕES')
         .moveDown();

      doc.fontSize(10)
         .font('Helvetica')
         .text(jornada.observacoes)
         .moveDown();
    }

    // Assinaturas
    doc.fontSize(14)
       .font('Helvetica-Bold')
       .text('ASSINATURAS')
       .moveDown();

    doc.fontSize(10)
       .font('Helvetica')
       .text('Motorista: _________________________________')
       .text('Data: _________________________________')
       .moveDown();

    doc.text('Gerente: _________________________________')
       .text('Data: _________________________________')
       .moveDown(2);

    // Declaração do motorista
    doc.fontSize(10)
       .font('Helvetica')
       .text('Por ser verdade, firmo o presente, Rio Verde-GO, ' + moment().format('DD/MM/YYYY') + '.')
       .moveDown();

    doc.text('_________________________________')
       .text('Motorista')
       .moveDown();

    // Rodapé
    doc.fontSize(8)
       .font('Helvetica')
       .text('Documento gerado automaticamente pelo sistema da Revenda Lima', { align: 'center' });

    // Finalizar o documento
    doc.end();

  } catch (error) {
    console.error('Erro ao gerar PDF:', error);
    res.status(500).json({
      error: 'Erro interno do servidor'
    });
  }
});

// Rota para gerar relatório consolidado em PDF
router.post('/relatorio-consolidado/pdf', authenticateAdmin, (req, res) => {
  try {
    const { dataInicio, dataFim, motoristaId, placa } = req.body;

    if (!dataInicio || !dataFim) {
      return res.status(400).json({
        error: 'Data início e data fim são obrigatórias'
      });
    }

    // Filtrar jornadas
    let jornadasFiltradas = jornadas.filter(j => {
      const dataJornada = moment(j.dataJornada);
      return dataJornada.isBetween(dataInicio, dataFim, 'day', '[]');
    });

    if (motoristaId) {
      jornadasFiltradas = jornadasFiltradas.filter(j => j.motoristaId === motoristaId);
    }

    if (placa) {
      jornadasFiltradas = jornadasFiltradas.filter(j => 
        j.placa.toLowerCase().includes(placa.toLowerCase())
      );
    }

    if (jornadasFiltradas.length === 0) {
      return res.status(404).json({
        error: 'Nenhuma jornada encontrada para o período especificado'
      });
    }

    // Configurar cabeçalho para download do PDF
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="relatorio-jornadas-${dataInicio}-${dataFim}.pdf"`);

    // Criar documento PDF
    const doc = new PDFDocument({
      size: 'A4',
      margins: {
        top: 50,
        bottom: 50,
        left: 50,
        right: 50
      }
    });

    // Pipe do PDF para a resposta
    doc.pipe(res);

    // Cabeçalho do relatório
    doc.fontSize(20)
       .font('Helvetica-Bold')
       .text('RELATÓRIO CONSOLIDADO DE JORNADAS', { align: 'center' })
       .moveDown();

    doc.fontSize(12)
       .font('Helvetica')
       .text(`Revenda Lima - Período: ${moment(dataInicio).format('DD/MM/YYYY')} a ${moment(dataFim).format('DD/MM/YYYY')}`, { align: 'center' })
       .moveDown(2);

    // Resumo estatístico
    const totalKm = jornadasFiltradas.reduce((sum, j) => sum + j.kmTotal, 0);
    const totalHoras = jornadasFiltradas.reduce((sum, j) => sum + j.tempoJornada.total, 0);
    const jornadasAssinadas = jornadasFiltradas.filter(j => j.status === 'assinada').length;

    doc.fontSize(14)
       .font('Helvetica-Bold')
       .text('RESUMO ESTATÍSTICO')
       .moveDown();

    doc.fontSize(10)
       .font('Helvetica')
       .text(`Total de Jornadas: ${jornadasFiltradas.length}`)
       .text(`Jornadas Assinadas: ${jornadasAssinadas}`)
       .text(`Total de KM: ${totalKm}`)
       .text(`Total de Horas: ${totalHoras.toFixed(2)}h`)
       .moveDown(2);

    // Tabela de jornadas
    doc.fontSize(14)
       .font('Helvetica-Bold')
       .text('DETALHAMENTO DAS JORNADAS')
       .moveDown();

    // Cabeçalho da tabela
    const tableTop = doc.y;
    const colWidth = 120;
    const rowHeight = 20;

    // Cabeçalhos das colunas
    doc.fontSize(8)
       .font('Helvetica-Bold')
       .text('Data', 50, tableTop)
       .text('Motorista', 50, tableTop)
       .text('Placa', 50 + colWidth, tableTop)
       .text('Destino', 50 + colWidth * 2, tableTop)
       .text('KM', 50 + colWidth * 3, tableTop)
       .text('Tempo', 50 + colWidth * 4, tableTop);

    // Linhas da tabela
    let currentY = tableTop + rowHeight;
    jornadasFiltradas.forEach((jornada, index) => {
      if (currentY > 700) { // Nova página se necessário
        doc.addPage();
        currentY = 50;
      }

      doc.fontSize(8)
         .font('Helvetica')
         .text(moment(jornada.dataJornada).format('DD/MM'), 50, currentY)
         .text(jornada.motoristaNome.substring(0, 15), 50 + colWidth, currentY)
         .text(jornada.placa, 50 + colWidth * 2, currentY)
         .text(jornada.destino.substring(0, 15), 50 + colWidth * 3, currentY)
         .text(jornada.kmTotal.toString(), 50 + colWidth * 4, currentY)
         .text(`${jornada.tempoJornada.horas}h${jornada.tempoJornada.minutos}m`, 50 + colWidth * 5, currentY);

      currentY += rowHeight;
    });

    // Rodapé
    doc.fontSize(8)
       .font('Helvetica')
       .text('Documento gerado automaticamente pelo sistema da Revenda Lima', { align: 'center' });

    // Finalizar o documento
    doc.end();

  } catch (error) {
    console.error('Erro ao gerar relatório consolidado:', error);
    res.status(500).json({
      error: 'Erro interno do servidor'
    });
  }
});

// Rota para obter estatísticas das jornadas
router.get('/estatisticas', authenticateAdmin, (req, res) => {
  try {
    const { dataInicio, dataFim } = req.query;

    let jornadasFiltradas = [...jornadas];

    // Filtro por data se fornecido
    if (dataInicio && dataFim) {
      jornadasFiltradas = jornadasFiltradas.filter(j => {
        const dataJornada = moment(j.dataJornada);
        return dataJornada.isBetween(dataInicio, dataFim, 'day', '[]');
      });
    }

    // Calcular estatísticas
    const totalJornadas = jornadasFiltradas.length;
    const jornadasAssinadas = jornadasFiltradas.filter(j => j.status === 'assinada').length;
    const jornadasPendentes = totalJornadas - jornadasAssinadas;
    
    const totalKm = jornadasFiltradas.reduce((sum, j) => sum + j.kmTotal, 0);
    const totalHoras = jornadasFiltradas.reduce((sum, j) => sum + j.tempoJornada.total, 0);
    
    const mediaKmPorJornada = totalJornadas > 0 ? totalKm / totalJornadas : 0;
    const mediaHorasPorJornada = totalJornadas > 0 ? totalHoras / totalJornadas : 0;

    // Estatísticas por motorista
    const estatisticasPorMotorista = {};
    jornadasFiltradas.forEach(j => {
      if (!estatisticasPorMotorista[j.motoristaId]) {
        estatisticasPorMotorista[j.motoristaId] = {
          nome: j.motoristaNome,
          totalJornadas: 0,
          totalKm: 0,
          totalHoras: 0
        };
      }
      
      estatisticasPorMotorista[j.motoristaId].totalJornadas++;
      estatisticasPorMotorista[j.motoristaId].totalKm += j.kmTotal;
      estatisticasPorMotorista[j.motoristaId].totalHoras += j.tempoJornada.total;
    });

    res.json({
      success: true,
      estatisticas: {
        periodo: {
          dataInicio: dataInicio || 'Todas',
          dataFim: dataFim || 'Todas'
        },
        geral: {
          totalJornadas,
          jornadasAssinadas,
          jornadasPendentes,
          totalKm,
          totalHoras,
          mediaKmPorJornada: Math.round(mediaKmPorJornada * 100) / 100,
          mediaHorasPorJornada: Math.round(mediaHorasPorJornada * 100) / 100
        },
        porMotorista: Object.values(estatisticasPorMotorista)
      }
    });

  } catch (error) {
    console.error('Erro ao obter estatísticas:', error);
    res.status(500).json({
      error: 'Erro interno do servidor'
    });
  }
});

module.exports = router;
