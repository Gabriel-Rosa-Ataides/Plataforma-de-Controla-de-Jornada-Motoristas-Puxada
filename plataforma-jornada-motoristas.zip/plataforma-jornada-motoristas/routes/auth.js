const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const router = express.Router();

// Simulação de banco de dados em memória (em produção usar SQLite ou outro)
let users = [
  {
    id: '1',
    username: 'admin',
    password: 'admin123', // Senha simples para teste
    role: 'admin',
    nome: 'Administrador',
    email: 'admin@revendalima.com'
  },
  {
    id: '2',
    username: 'motorista1',
    password: 'motorista123', // Senha simples para teste
    role: 'motorista',
    nome: 'João Silva',
    email: 'joao.silva@revendalima.com',
    placa: 'ABC-1234'
  }
];

// Rota de login
router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;

    console.log('Tentativa de login:', { username, password });

    if (!username || !password) {
      return res.status(400).json({ 
        error: 'Usuário e senha são obrigatórios' 
      });
    }

    const user = users.find(u => u.username === username);
    if (!user) {
      console.log('Usuário não encontrado:', username);
      return res.status(401).json({ 
        error: 'Usuário ou senha inválidos' 
      });
    }

    console.log('Usuário encontrado:', user.username, 'Role:', user.role);

    // Comparação simples de senha para teste
    if (user.password !== password) {
      console.log('Senha incorreta para usuário:', username);
      return res.status(401).json({ 
        error: 'Usuário ou senha inválidos' 
      });
    }

    console.log('Login bem-sucedido para:', username);

    const token = jwt.sign(
      { 
        userId: user.id, 
        username: user.username, 
        role: user.role 
      },
      process.env.JWT_SECRET || 'revenda-lima-secret-key',
      { expiresIn: '24h' }
    );

    res.json({
      success: true,
      token,
      user: {
        id: user.id,
        username: user.username,
        role: user.role,
        nome: user.nome,
        email: user.email,
        placa: user.placa
      }
    });

  } catch (error) {
    console.error('Erro no login:', error);
    res.status(500).json({ 
      error: 'Erro interno do servidor' 
    });
  }
});

// Rota para verificar token
router.get('/verify', (req, res) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    
    if (!token) {
      return res.status(401).json({ 
        error: 'Token não fornecido' 
      });
    }

    const decoded = jwt.verify(
      token, 
      process.env.JWT_SECRET || 'revenda-lima-secret-key'
    );

    const user = users.find(u => u.id === decoded.userId);
    if (!user) {
      return res.status(401).json({ 
        error: 'Usuário não encontrado' 
      });
    }

    res.json({
      valid: true,
      user: {
        id: user.id,
        username: user.username,
        role: user.role,
        nome: user.nome,
        email: user.email,
        placa: user.placa
      }
    });

  } catch (error) {
    console.error('Erro na verificação do token:', error);
    res.status(401).json({ 
      error: 'Token inválido' 
    });
  }
});

// Rota para criar novo usuário (apenas admin)
router.post('/register', async (req, res) => {
  try {
    const { username, password, nome, email, role, placa } = req.body;

    if (!username || !password || !nome || !email || !role) {
      return res.status(400).json({ 
        error: 'Todos os campos são obrigatórios' 
      });
    }

    if (users.find(u => u.username === username)) {
      return res.status(400).json({ 
        error: 'Usuário já existe' 
      });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = {
      id: uuidv4(),
      username,
      password: hashedPassword,
      nome,
      email,
      role,
      placa: role === 'motorista' ? placa : null
    };

    users.push(newUser);

    res.status(201).json({
      success: true,
      message: 'Usuário criado com sucesso',
      user: {
        id: newUser.id,
        username: newUser.username,
        role: newUser.role,
        nome: newUser.nome,
        email: newUser.email,
        placa: newUser.placa
      }
    });

  } catch (error) {
    console.error('Erro ao criar usuário:', error);
    res.status(500).json({ 
      error: 'Erro interno do servidor' 
    });
  }
});

module.exports = router;
