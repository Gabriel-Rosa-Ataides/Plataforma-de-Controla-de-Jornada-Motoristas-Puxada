const http = require('http');

console.log('🧪 Testando API de Login...');

// Teste com usuário admin
const adminData = JSON.stringify({
  username: 'admin',
  password: 'admin123'
});

const adminOptions = {
  hostname: 'localhost',
  port: 3001,
  path: '/api/auth/login',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': adminData.length
  }
};

console.log('\n🔐 Testando login como Admin...');
const adminReq = http.request(adminOptions, (res) => {
  console.log(`Status: ${res.statusCode}`);
  
  res.on('data', (chunk) => {
    const data = JSON.parse(chunk.toString());
    console.log('Resposta:', data);
    
    if (data.success) {
      console.log('✅ Login admin bem-sucedido!');
      console.log('Token:', data.token);
      console.log('Usuário:', data.user);
    } else {
      console.log('❌ Login admin falhou:', data.error);
    }
  });
});

adminReq.on('error', (e) => {
  console.error('❌ Erro na requisição admin:', e.message);
});

adminReq.write(adminData);
adminReq.end();

// Teste com usuário motorista
setTimeout(() => {
  console.log('\n🚛 Testando login como Motorista...');
  
  const motoristaData = JSON.stringify({
    username: 'motorista1',
    password: 'motorista123'
  });

  const motoristaOptions = {
    hostname: 'localhost',
    port: 3001,
    path: '/api/auth/login',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': motoristaData.length
    }
  };

  const motoristaReq = http.request(motoristaOptions, (res) => {
    console.log(`Status: ${res.statusCode}`);
    
    res.on('data', (chunk) => {
      const data = JSON.parse(chunk.toString());
      console.log('Resposta:', data);
      
      if (data.success) {
        console.log('✅ Login motorista bem-sucedido!');
        console.log('Token:', data.token);
        console.log('Usuário:', data.user);
      } else {
        console.log('❌ Login motorista falhou:', data.error);
      }
    });
  });

  motoristaReq.on('error', (e) => {
    console.error('❌ Erro na requisição motorista:', e.message);
  });

  motoristaReq.write(motoristaData);
  motoristaReq.end();
}, 1000);
