const http = require('http');

// Teste da rota de verificação de auth
console.log('🧪 Testando API de Autenticação...');

const req = http.request({
  hostname: 'localhost',
  port: 3001,
  path: '/api/auth/verify',
  method: 'GET'
}, (res) => {
  console.log(`✅ Status: ${res.statusCode}`);
  
  res.on('data', (chunk) => {
    console.log(`📄 Resposta: ${chunk.toString()}`);
  });
});

req.on('error', (e) => {
  console.error(`❌ Erro: ${e.message}`);
});

req.end();
