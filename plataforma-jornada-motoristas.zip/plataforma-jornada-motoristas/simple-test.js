const http = require('http');

console.log('🧪 Testando servidor...');

const req = http.request({
  hostname: 'localhost',
  port: 3001,
  path: '/',
  method: 'GET'
}, (res) => {
  console.log(`✅ Status: ${res.statusCode}`);
  console.log('✅ Servidor funcionando!');
});

req.on('error', (e) => {
  console.error(`❌ Erro: ${e.message}`);
});

req.end();
